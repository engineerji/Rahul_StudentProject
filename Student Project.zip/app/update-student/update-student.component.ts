import { Component, OnInit, Input } from '@angular/core';
import { Student } from '../student';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-update-student',
  templateUrl: './update-student.component.html',
  styleUrls: ['./update-student.component.css']
})
export class UpdateStudentComponent implements OnInit {
  @Input() updatableAccount : Student;
  accountsService:MyServiceService;
  constructor(accountsService : MyServiceService) {
    this.accountsService = accountsService;
    
   }

  ngOnInit() {
    
  }
  doUpdate()
  {
    console.log("---> doUpdate Update Accounts"+this.updatableAccount.phone+"");
     this.accountsService.setUpdatableAccounts(this.updatableAccount);
  }
}
