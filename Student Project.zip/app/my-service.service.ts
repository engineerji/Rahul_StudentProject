import { Injectable } from '@angular/core';
import { Student } from './student';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  students:Array<Student>=[];
  private endPoint = '/assets/data/Student.json';
  updatableAccounts : Student = new Student('',0,0,'','');
  constructor(private http:HttpClient) { 
    let stud=new Student("nahbsa",8,8,"9867453","hgbsa.saj");
    this.students.push(stud);
  }

  
  
  addStudent(student:Student){
    this.students.push(student);
    console.log(this.students[0]);
    console.log(this.students[1]);
    console.log(this.students[2]);
  }
  getStudentsFromServer():Observable<MyServiceService[]>{
    return this.http.get<MyServiceService[]>(this.endPoint);
  }

  getStudents(){
    return this.students;
  }
  setUpdatableAccounts(uacc: Student)
  {
    this.updatableAccounts = uacc;

    console.log(" ----------- Service Set --------------");
    let a:Student = this.updatableAccounts;
    console.log(" Name "+a.name);
    console.log(" Age "+a.age);
    console.log(" Marks "+a.marks);
    console.log(" Phone "+a.phone);
    console.log("Email"+a.email);
  }
  searchAccountsByPhone(searchPhone)
  {
    let isFound : boolean = false;
    for(let acc of this.students)
    {
        if(acc.phone == searchPhone)
        {
            isFound = true;
            return acc;
            break;
        }
    }
    if(isFound == false) return null;
  }
}
