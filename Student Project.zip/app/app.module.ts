import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { MyServiceService } from './my-service.service';
import { AddNewStudentComponent } from './add-new-student/add-new-student.component';
import { DisplayAllComponent } from './display-all/display-all.component';
import { SearchComponent } from './search/search.component';
import { HttpNewComponent } from './http-new/http-new.component';
import { HttpClientModule } from '@angular/common/http';
import { UpdateStudentComponent } from './update-student/update-student.component';

@NgModule({
  declarations: [
    AppComponent,
    AddNewStudentComponent,
    DisplayAllComponent,
    SearchComponent,
    HttpNewComponent,
    UpdateStudentComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
