import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Student } from '../student';

@Component({
  selector: 'app-display-all',
  templateUrl: './display-all.component.html',
  styleUrls: ['./display-all.component.css']
})
export class DisplayAllComponent implements OnInit {
  students=[];
  __service:MyServiceService;
  updatableStudent:Student;
  isEditable:boolean=false;
  constructor(__service:MyServiceService) { 
    this.__service=__service;
  }

  ngOnInit(): void {
    this.students=this.__service.getStudents();
    console.log(this.students[0])
  }
  doEdit(stud:Student){
    this.isEditable=true;
    console.log("-----------Update All doEdit event-------------");
    this.updatableStudent=stud;
  }

}
