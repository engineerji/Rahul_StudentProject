import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HttpNewComponent } from './http-new.component';

describe('HttpNewComponent', () => {
  let component: HttpNewComponent;
  let fixture: ComponentFixture<HttpNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HttpNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HttpNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
