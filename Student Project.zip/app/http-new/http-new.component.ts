import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';

@Component({
  selector: 'app-http-new',
  templateUrl: './http-new.component.html',
  styleUrls: ['./http-new.component.css']
})
export class HttpNewComponent implements OnInit {

  students=[];
  private __studservice:MyServiceService;
  constructor(__studservice:MyServiceService) {
    this.__studservice=__studservice;
   }

  ngOnInit(): void {
    this.__studservice.getStudentsFromServer()
    .subscribe(data=>this.students = data);
    console.log("http observable"+this.students.length);
  }

}
