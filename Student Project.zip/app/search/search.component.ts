import { Component, OnInit } from '@angular/core';
import { MyServiceService } from '../my-service.service';
import { Student } from '../student';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  students=[];
  __service:MyServiceService;
  
  constructor(__service:MyServiceService) { 
    this.__service=__service;
  }

  ngOnInit(): void {
    this.students=this.__service.getStudents();
    console.log(this.students[0])
  }
  letsSearch(phone)
  {
    console.log(phone.value);
    let acc:Student  = this.__service.searchAccountsByPhone(phone.value);
    if(acc != null)
    {
      alert(" Record Found : "+acc.name+","+acc.age+" , "+","+acc.marks+" , "+","+acc.phone+" , "+acc.email);
    }
    else{
      alert(" Record Not Found "+phone.value);
    }
   
  }

}
